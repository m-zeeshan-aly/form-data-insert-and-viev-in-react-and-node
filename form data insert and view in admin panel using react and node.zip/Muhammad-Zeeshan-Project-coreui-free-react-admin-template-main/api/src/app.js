const fs = require("fs/promises");
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
//const _ = require("lodash");
const {v4: uuid}= require("uuid");

require("./db/conn");
const User = require("./models/users");


const app = express();

const port = process.env.PORT || 5000;

// app.get("/",(req,res)=>{
//     res.send("Hello i a alive respose.");
// });

app.use(express.json())
// app.post("/users",(req,res)=>{
//     //console.log(req.body);
//     const user= new User(req.body);

//     user.save().then(() => { 
//         res.status(201);
//         res.send(user);
        
//     }).catch((e) => {
//         res.status(400).send(e);
//     });
//     //res.send("respose from other side.");
// });




app.use(cors());
app.post("/users",async(req,res)=> {
    try {
        const user= new User(req.body);

        const createUser = await  user.save(req.body);

         res.status(201).send(createUser);
        
    } catch (error) {res.status(400).send(e);}
    

})







//app.use(express.json())

app.use(cors());
app.get("/users",async(req,res)=>{
    try {
        const usersData= await User.find();
        res.send(usersData);
    } catch (e) {
        res.send(e);
    }
   
});

app.get("/users/:id",async(req,res)=>{
    try {
        const _email= req.params.email;

        const userData = await User.findById(_email);

        if (!userData){
            return res.status(404).send();
        }else{
            res.send(userData);
        }
        
    } catch (e) {
        res.status(500).send(e);
    }
   
});

app.listen(port,()=>
console.log(`API Server is running... ${port} on this port.`));