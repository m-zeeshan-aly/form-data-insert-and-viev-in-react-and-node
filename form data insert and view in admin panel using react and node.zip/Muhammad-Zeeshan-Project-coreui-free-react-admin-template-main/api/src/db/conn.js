
const mangoose = require("mongoose");



mangoose.connect("mongodb+srv://adminuser:adminuser@cluster1.7rcpkrr.mongodb.net/?retryWrites=true&w=majority").then(()=>{
    console.log("connected hai ha");
}).catch((e)=>{
    console.log("not connected");
})