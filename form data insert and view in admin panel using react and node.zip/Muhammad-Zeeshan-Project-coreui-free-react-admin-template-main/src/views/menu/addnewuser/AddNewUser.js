import React ,{useNavigate,useState} from 'react';

import axios from 'axios';

import { useDispatch } from 'react-redux'

import {
  CButton,
  CCard,
  CCardBody,
  CCol,
  CContainer,
  CForm,
  CFormInput,
  CInputGroup,
  CInputGroupText,
  CRow,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilPhone, cilSortNumericUp, cilUser } from '@coreui/icons'

import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import validator from 'validator'
import Register from 'src/views/pages/register/Register'
import { bool } from 'prop-types';


const AddNewUser = () => {

  //const dispatch = useDispatch();


  const [name, setName] = useState('');

  const [email, setEmail] = useState('')

  const [phone, setNumber] = useState('')

  const [age, setAge] = useState('')

  const [ageError, setAgeError] = useState("")



  // const sendApiData = async()=> {

  //   console.log("inside the send data")
  //   try{
  //   const res = await axios.post("http://localhost:5000/users",userdata);
  //   // setData(res.data)
  //   //setData(res.data)
  //   console.log(res.data)
  //   }catch(error){
  //     setIsError(error.message);
  //     //console.log("file : ViewAllusers line 15 ~ useEffect ~error",error)
  //   }
  // };
  //const [data, setData]=useState([]);






  const sendApiData = async()=> {
    try{
    const res = await axios.post("http://localhost:5000/users");
    // setData(res.data)
    //setData(res.data)
    console.log(response);
    }catch(error){
      //setIsError(error.message);
      //console.log("file : ViewAllusers line 15 ~ useEffect ~error",error)
      toast.error("cannot add years.",{position:"top-center"})

    }

  };



  const submitform = (e) => {

    
    e.preventDefault();
   
    const userdata = { name: name, email: email, age: age, phone: phone }

    console.log(userdata);
    
    if (age>=18&& age<=60){

      e.target.reset();
      console.log(age);

      // if (validator.isEmail(email)) {
      //   toast.success("User added successfully e.",{position:"top-center"})
      // } else {
      //   toast.info("ENter a vaild email.",{position:"top-center"})
      // }

      // axios.post('http://localhost:5000/user',userdata)
      // .then(function (response) {
      //   console.log(response);
      // })
      // .catch(function (error) {
      //   console.log(error);
      //   toast.error("cannot add years.",{position:"top-center"})
      // });

      

      try{
        const res = axios.post("http://localhost:5000/users",userdata);
        toast.success("User is added sucessfully.",{position:"top-center"})
        
        console.log(res);
        
        }catch(error){
          console.log(res);
          toast.error("cannot add years.",{position:"top-center"})
         
        }

    }else{
      setAgeError("Age must be between 18 to 60 years")

      //toast.info("Age Must be in between 18 to  60 years.",{position:"top-center"})
    }
    // useEffect(()=>{
    //   sendApiData();
    // },[]);

    
  }


 


    

  


  return (
    <div className="bg-light min-vh-100 d-flex flex-row align-items-center">
      <CContainer>
        <CRow className="justify-content-center">
          <CCol md={9} lg={7} xl={6}>
            <CCard className="mx-4">
              <CCardBody className="p-4">
                <CForm onSubmit={submitform}>

                
                  <h1>Add New User</h1>
                  
                  <p className="text-medium-emphasis">Create your account</p>

                  <p style={{color: "red"}}>{ageError}</p>

                  <CInputGroup className="mb-3">
                    <CInputGroupText>
                      <CIcon icon={cilUser} />
                    </CInputGroupText>

                    <CFormInput key ={1} type="text" placeholder="Name"  onChange={(e) => setName(e.target.value)} required />
                  </CInputGroup>

                  <CInputGroup   className="mb-3">
                    <CInputGroupText>@</CInputGroupText>

                    <CFormInput key ={2 } type="email"  placeholder="example@gmail.com" 
                     onChange={(e) => setEmail(e.target.value)}
                     required />

                  </CInputGroup>

                  <CInputGroup   className="mb-3">
                    <CInputGroupText> <CIcon icon={cilSortNumericUp} /></CInputGroupText>

                    <CFormInput  key ={3 } type="Number"  placeholder="Age" 
                     onChange={(e) => setAge(e.target.value)} required />

                  </CInputGroup>

                  <CInputGroup   className="mb-3">
                    <CInputGroupText><CIcon icon={cilPhone} /></CInputGroupText>

                    <CFormInput  key ={4 } type="text"  placeholder="Phone" 
                      onChange={(e) => setNumber(e.target.value)} required />

                  </CInputGroup>

                 
                  <div className="d-grid">
                    <CButton type='submit' color="success">Submit</CButton>
                    <ToastContainer />
                  </div>

                </CForm>

                
              </CCardBody>
            </CCard>
          </CCol>
        </CRow>
      </CContainer>
    </div>
  )
}

export default AddNewUser
