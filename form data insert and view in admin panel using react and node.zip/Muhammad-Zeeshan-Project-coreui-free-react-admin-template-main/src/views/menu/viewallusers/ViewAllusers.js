import React, { useEffect ,useState } from 'react'
import axios from 'axios'

//header('Access-Control-Allow-Origin: http://localhost:5000/users');



//import {Users} from "./users"
import {
  CCard,
  CButton,
  CCardBody,
  CCardHeader,
  CCol,
  CRow,
  CTable,
  CTableBody,
  CTableCaption,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
} from '@coreui/react'
//import { DocsExample } from 'src/components'

const ViewAllUsers = () => {

  const [isError,setIsError]=useState("");
  const [data, setData]=useState([]);

  //const [count,setCount]=useState();
  //setCount(0);

  let count=0;


  // useEffect(()=>{  
  //   axios
  //   .get("http://localhost:5000/users")
  //   .then((res)=> setData(res.data))
  //   .catch((error)=>{
  //     setIsError(error.message);
  //     //console.log("file : ViewAllusers line 15 ~ useEffect ~error",error)
  //   })

  // },[]);

  // console.log(data);

  ///////////////////////// 2nd way
  

  const getApiData = async()=> {
    try{
    const res = await axios.get("http://localhost:5000/users");
    // setData(res.data)
    setData(res.data)
    }catch(error){
      setIsError(error.message);
      //console.log("file : ViewAllusers line 15 ~ useEffect ~error",error)
    }
  };


  useEffect(()=>{
    getApiData();
  },[]);


  return (
    <CRow>
      <CCol xs={12}>
        <CCard className="mb-4">
          <CCardHeader>
            <strong>Users Table</strong> <small>All users</small>
          </CCardHeader>
          
          <CCardBody>
          <CButton type='submit' color="success" style={{ textAlign: "center",color:"white", backgroundColor:"blue" }}>search User</CButton>
            
            
              <CTable caption="top">
              

                <CTableCaption>List of users</CTableCaption>

                <CTableHead>
                  <CTableRow>
                    <CTableHeaderCell scope="col">#</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Name</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Email</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Age</CTableHeaderCell>
                    <CTableHeaderCell scope="col">Phone</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>



                {data.map((output)=>{
                  count=count+1;
                  const {id,name,email,age,phone}=output;
                return(

                <CTableRow key={id}>
                  <CTableHeaderCell>{count}</CTableHeaderCell>
                  <CTableDataCell>{name}</CTableDataCell>
                  <CTableDataCell>{email}</CTableDataCell>
                  <CTableDataCell>{age}</CTableDataCell>
                  <CTableDataCell>{phone}</CTableDataCell>
                </CTableRow>
                );

                })}

                
              </CTable>
            
          </CCardBody>
        </CCard>
      </CCol>
      
      
    </CRow>
  )
}




export default ViewAllUsers

