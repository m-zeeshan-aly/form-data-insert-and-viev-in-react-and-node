
import changeState from "./changeState";

import { combineReducers } from "redux";





const rootReducer = combineReducers({
    changeState
});


export default rootReducer;