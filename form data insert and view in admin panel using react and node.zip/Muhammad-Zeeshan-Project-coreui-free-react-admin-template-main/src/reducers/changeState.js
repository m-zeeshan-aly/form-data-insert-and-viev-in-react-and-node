//import { initialState } from "src/actions/Actions";

//import { createStore } from 'redux';

export const initialState = {
  sidebarShow: true,
}

const changeState = (state = initialState, { type, ...rest }) => {
    switch (type) {
      case 'set':
        return { ...state, ...rest }
      default:
        return state
    }
  }

export default changeState;